import Foundation

class ReviewSaveData {
    
    let type: ReviewType
    let id: String?
    let score: Int
    let message: String?
    
    init(type: ReviewType, id: String? = nil, score: Int, message: String? = nil) {
        self.type = type
        self.id = id
        self.score = score
        self.message = message
    }
    
    class func read() -> [ReviewSaveData] {
        
        var datas = [ReviewSaveData]()
        let userDefaults = UserDefaults()
        var i = 0
        
        while true {
            if let typeString = userDefaults.string(forKey: Constants.UserDefaultsKey.Review.type + "\(i)"), let type = ReviewType(rawValue: typeString) {
                let id = userDefaults.string(forKey: Constants.UserDefaultsKey.Review.id + "\(i)")
                let score = Int(userDefaults.string(forKey: Constants.UserDefaultsKey.Review.score + "\(i)") ?? "") ?? 0
                let message = userDefaults.string(forKey: Constants.UserDefaultsKey.Review.message)
                datas.append(ReviewSaveData(type: type, id: id, score: score, message: message))
            } else {
                break
            }
            i += 1
        }
        return datas
    }
    
    class func save(datas: [ReviewSaveData]) {
        
        let userDefaults = UserDefaults()
        
        datas.enumerated().forEach { i, data in
            userDefaults.set(data.type.rawValue, forKey: Constants.UserDefaultsKey.Review.type + "\(i)")
            if let id = data.id {
                userDefaults.set(id, forKey: Constants.UserDefaultsKey.Review.id + "\(i)")
            } else {
                userDefaults.removeObject(forKey: Constants.UserDefaultsKey.Review.id + "\(i)")
            }
            userDefaults.set("\(data.score)", forKey: Constants.UserDefaultsKey.Review.score + "\(i)")
            if let message = data.message {
                userDefaults.set(message, forKey: Constants.UserDefaultsKey.Review.message + "\(i)")
            } else {
                userDefaults.removeObject(forKey: Constants.UserDefaultsKey.Review.message + "\(i)")
            }
        }
        userDefaults.synchronize()
    }
    
    func compare(type: ReviewType, targetId: String?) -> Bool {
        
        if self.type == .home {
            return type == .home
        } else {
            if let id = self.id, let targetId = targetId {
                return id == targetId
            }
            return false
        }
    }
}
