import Foundation

class SaveData {
    
    static let shared = SaveData()
    
    var userId = ""
    var userName = ""
    var reviews = [ReviewSaveData]()
    var likes = [LikeSaveData]()
    
    init() {
        let userDefaults = UserDefaults()
        self.userId = userDefaults.string(forKey: Constants.UserDefaultsKey.UserId) ?? ""
        self.userName = userDefaults.string(forKey: Constants.UserDefaultsKey.UserName) ?? ""
        self.reviews = ReviewSaveData.read()
        self.likes = LikeSaveData.read()
    }
    
    func save() {
        
        let userDefaults = UserDefaults()
        userDefaults.set(self.userId, forKey: Constants.UserDefaultsKey.UserId)
        userDefaults.set(self.userName, forKey: Constants.UserDefaultsKey.UserName)
        ReviewSaveData.save(datas: self.reviews)
        LikeSaveData.save(datas: self.likes)
        userDefaults.synchronize()
    }
    
    func append(reviewSaveData: ReviewSaveData) {
        if let index = self.reviews.index(where: { $0.compare(type: reviewSaveData.type, targetId: reviewSaveData.id) }) {
            self.reviews.remove(at: index)
        }
        self.reviews.append(reviewSaveData)
    }
    
    func append(likeSaveData: LikeSaveData) {
        if let index = self.likes.index(where: { $0.compare(type: likeSaveData.type, targetId: likeSaveData.id) }) {
            self.likes.remove(at: index)
        }
        self.likes.append(likeSaveData)
    }
}
