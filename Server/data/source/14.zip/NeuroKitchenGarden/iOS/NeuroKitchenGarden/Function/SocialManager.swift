import Social

enum SocialType {
    case facebook
    case twitter
}

class SocialManager {
    
    class func post(to: SocialType, from: UIViewController, initialText: String, image: UIImage?) {
        
        let serviceType = (to == .facebook) ? SLServiceTypeFacebook : SLServiceTypeTwitter
        if let composeViewController = SLComposeViewController(forServiceType: serviceType) {
            composeViewController.setInitialText(initialText)
            composeViewController.add(image)
            from.present(composeViewController, animated: true)
        }
    }
}
