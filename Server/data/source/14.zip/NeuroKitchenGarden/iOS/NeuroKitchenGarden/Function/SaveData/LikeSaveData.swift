import Foundation

class LikeSaveData {
    
    let type: LikeType
    let id: String?
    
    init(type: LikeType, id: String? = nil) {
        self.type = type
        self.id = id
    }
    
    class func read() -> [LikeSaveData] {
        
        var datas = [LikeSaveData]()
        let userDefaults = UserDefaults()
        var i = 0
        
        while true {
            if let typeString = userDefaults.string(forKey: Constants.UserDefaultsKey.Like.type + "\(i)"), let type = LikeType(rawValue: typeString) {
                let id = userDefaults.string(forKey: Constants.UserDefaultsKey.Like.id + "\(i)")
                datas.append(LikeSaveData(type: type, id: id))
            } else {
                break
            }
            i += 1
        }
        return datas
    }
    
    class func save(datas: [LikeSaveData]) {
        
        let userDefaults = UserDefaults()
        
        datas.enumerated().forEach { i, data in
            userDefaults.set(data.type.rawValue, forKey: Constants.UserDefaultsKey.Like.type + "\(i)")
            if let id = data.id {
                userDefaults.set(id, forKey: Constants.UserDefaultsKey.Like.id + "\(i)")
            } else {
                userDefaults.removeObject(forKey: Constants.UserDefaultsKey.Like.id + "\(i)")
            }
        }
        userDefaults.synchronize()
    }
    
    func compare(type: LikeType, targetId: String?) -> Bool {
        
        if self.type == .home {
            return type == .home
        } else {
            if let id = self.id, let targetId = targetId {
                return id == targetId
            }
            return false
        }
    }    
}
