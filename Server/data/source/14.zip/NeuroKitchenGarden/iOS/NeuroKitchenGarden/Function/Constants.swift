import Foundation

struct Constants {
    static let HttpTimeOutInterval = TimeInterval(10)
    static let ServerUrl = "https://leapfrog.sakura.ne.jp/samples/neuro_kitchen_garden/srv.php"
    static let StringEncoding = String.Encoding.utf8
    
    struct UserDefaultsKey {
        static let UserId = "UserId"
        static let UserName = "UserName"
        
        struct Review {
            static let type = "ReviewType"
            static let id = "ReviewId"
            static let score = "ReviewScore"
            static let message = "ReviewMessage"
        }
        
        struct Like {
            static let type = "LikeType"
            static let id = "LikeId"
        }
    }
}
