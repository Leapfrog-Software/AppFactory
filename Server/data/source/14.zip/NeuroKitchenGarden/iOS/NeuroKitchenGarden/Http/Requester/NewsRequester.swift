import Foundation

struct NewsData {
    
    let id: String
    let imageUrl: String
    let title: String
    let body: String
    let date: String
    
    init?(data: Dictionary<String, Any>) {
        
        guard let id = data["id"] as? String else {
            return nil
        }
        self.id = id
        
        imageUrl = data["imageUrl"] as? String ?? ""
        title = data["title"] as? String ?? ""
        body = data["body"] as? String ?? ""
        date = data["date"] as? String ?? ""
    }
}

class NewsRequester {
    
    static let shared = NewsRequester()
    
    var dataList = [NewsData]()
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        self.dataList.removeAll()
        
        let params = [
            "command": "getNews"
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                self.dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { NewsData(data: $0) }
                completion(true)
                return
            }
            completion(false)
        }
    }
}
