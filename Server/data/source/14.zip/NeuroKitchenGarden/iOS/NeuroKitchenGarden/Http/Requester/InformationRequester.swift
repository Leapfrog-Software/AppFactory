import Foundation

struct InformationData {
    
    let imageUrl: String
    let storeName: String
    let description: String
    let latitude: String
    let longitude: String
    let address: String
    let phone: String
    let openTime: String
    let closeTime: String
    
    init?(data: Dictionary<String, Any>) {
        
        imageUrl = data["imageUrl"] as? String ?? ""
        storeName = data["storeName"] as? String ?? ""
        description = data["description"] as? String ?? ""
        latitude = data["latitude"] as? String ?? ""
        longitude = data["longitude"] as? String ?? ""
        address = data["address"] as? String ?? ""
        phone = data["phone"] as? String ?? ""
        openTime = data["openTime"] as? String ?? ""
        closeTime = data["closeTime"] as? String ?? ""
    }
}

class InformationRequester {
    
    static let shared = InformationRequester()
    
    var informationData: InformationData? = nil
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        let params = [
            "command": "getInformation"
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Dictionary<String, Any> {
                self.informationData = InformationData(data: data)
                completion(true)
                return
            }
        }
        completion(false)
    }
}
