import UIKit

enum ReviewType: String {
    case home = "0"
    case coupon = "1"
    case menu = "2"
}

struct ReviewData {
    
    let type: ReviewType
    let target: String
    let userId: String
    let name: String
    let score: Int
    let message: String?
    let date: Date
    
    init?(data: Dictionary<String, Any>) {
        
        guard let typeString = data["type"] as? String, let type = ReviewType(rawValue: typeString) else {
            return nil
        }
        self.type = type
        
        self.target = data["target"] as? String ?? ""
        self.userId = data["userId"] as? String ?? ""
        
        guard let name = (data["name"] as? String ?? "").base64Decode() else {
            return nil
        }
        self.name = name
        
        self.score = Int(data["score"] as? String ?? "0") ?? 0
        self.message = (data["message"] as? String ?? "").base64Decode()
        
        guard let dateString = data["date"] as? String, let date = DateFormatter(format: "yyyyMMddHHmmss").date(from: dateString) else {
            return nil
        }
        self.date = date
    }
}

struct ReviewPostData {
    
    let type: ReviewType
    let target: String
    let userId: String
    let name: String
    let score: Int
    let message: String?
}

class ReviewRequester {
    
    static let shared = ReviewRequester()
    
    var dataList = [ReviewData]()
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        self.dataList.removeAll()
        
        let params = [
            "command": "getReview"
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                self.dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { ReviewData(data: $0) }
                completion(true)
                return
            }
            completion(false)
        }
    }
    
    class func post(data: ReviewPostData, completion: @escaping ((Bool) -> ())) {
        
        let params = [
            "command": "postReview",
            "type": data.type.rawValue,
            "target": data.target,
            "userId": data.userId,
            "name": data.name.base64Encode() ?? "",
            "score": "\(data.score)",
            "message": data.message?.base64Encode() ?? ""
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Dictionary<String, String> {
                if data["result"] == "0" {
                    completion(true)
                    return
                }
            }
            completion(false)
        }
    }
    
    func query(type: ReviewType, id: String? = nil) -> [ReviewData] {
        
        if let id = id {
            return self.dataList.filter{ $0.type == type && $0.target == id }
        } else {
            return self.dataList.filter{ $0.type == type }
        }
    }
    
    func queryReviewCount(type: ReviewType, id: String? = nil) -> Int {
        return self.query(type: type, id: id).count
    }
    
    func queryTotalScore(type: ReviewType, id: String? = nil) -> CGFloat {
        
        let reviewCount = self.queryReviewCount(type: type, id: id)
        if reviewCount == 0 {
            return 0
        }
        var score = 0
        let reviews = self.query(type: type, id: id)
        reviews.forEach {
            score += $0.score
        }
        return CGFloat(score) / CGFloat(reviewCount)
    }
    
    class func scoreToString(_ score: CGFloat) -> String {
        return String(format: "%.1f", score / 2)
    }
}
