import Foundation

enum LikeType: String {
    case home = "0"
    case coupon = "1"
    case menu = "2"
}

struct LikeData {
    
    let type: LikeType
    let target: String
    let userId: String
    
    init?(data: Dictionary<String, Any>) {
        
        guard let typeString = data["type"] as? String, let type = LikeType(rawValue: typeString) else {
            return nil
        }
        self.type = type
        
        self.target = data["target"] as? String ?? ""
        self.userId = data["userId"] as? String ?? ""
    }
}

struct LikePostData {

    let type: LikeType
    let target: String?
    let userId: String
}

class LikeRequester {
    
    static let shared = LikeRequester()
    
    var dataList = [LikeData]()
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        self.dataList.removeAll()
        
        let params = [
            "command": "getLike"
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                self.dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { LikeData(data: $0) }
                completion(true)
                return
            }
            completion(false)
        }
    }
    
    class func post(data: LikePostData, completion: @escaping ((Bool) -> ())) {
        
        let params = [
            "command": "postLike",
            "type": data.type.rawValue,
            "target": data.target ?? "",
            "userId": data.userId,
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Dictionary<String, String> {
                if data["result"] == "0" {
                    completion(true)
                    return
                }
            }
            completion(false)
        }
    }
    
    func query(type: LikeType, id: String? = nil) -> [LikeData] {
        
        if let id = id {
            return self.dataList.filter{ $0.type == type && $0.target == id }
        } else {
            return self.dataList.filter{ $0.type == type }
        }
    }
    
    func queryLikeCount(type: LikeType, id: String? = nil) -> Int {
        return self.query(type: type, id: id).count
    }
}
