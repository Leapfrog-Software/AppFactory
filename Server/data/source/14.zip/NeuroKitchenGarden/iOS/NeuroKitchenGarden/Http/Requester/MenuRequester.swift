import Foundation

struct MenuData {
    
    let id: String
    let imageUrl: String
    let name: String
    let description: String
    let price: String
    
    init?(data: Dictionary<String, Any>) {
        
        guard let id = data["menuId"] as? String else {
            return nil
        }
        self.id = id
        
        imageUrl = data["imageUrl"] as? String ?? ""
        name = data["name"] as? String ?? ""
        description = data["description"] as? String ?? ""
        price = data["price"] as? String ?? ""
    }
}

struct MenuCategoryData {
    
    let id: String
    let name: String
    let items: [MenuData]
    
    init?(data: Dictionary<String, Any>) {
        
        guard let id = data["categoryId"] as? String else {
            return nil
        }
        self.id = id
        
        self.name = data["name"] as? String ?? ""
        
        if let itemsData = data["items"] as? [Dictionary<String, Any>] {
            self.items = itemsData.flatMap{ MenuData(data: $0) }
        } else {
            self.items = [MenuData]()
        }
    }
}

class MenuRequester {
    
    static let shared = MenuRequester()
    
    var dataList = [MenuCategoryData]()
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        self.dataList.removeAll()
        
        let params = [
            "command": "getMenu"
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                self.dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { MenuCategoryData(data: $0) }
                completion(true)
                return
            }
            completion(false)
        }
    }
}
