import UIKit

class CouponDetailViewController: UIViewController {
    
    @IBOutlet private weak var couponImageView: UIImageView!
    @IBOutlet private weak var likeButtonView: LikeButtonView!
    @IBOutlet private weak var couponTitleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var scoreLabel: UILabel!
    @IBOutlet private weak var reviewLabel: UILabel!
    @IBOutlet private weak var likeLabel: UILabel!
    @IBOutlet private weak var intervalLabel: UILabel!
    @IBOutlet private weak var conditionLabel: UILabel!
    
    private var couponData: CouponData!
    
    func set(couponData: CouponData) {
        self.couponData = couponData
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ImageStorage.shared.fetch(url: self.couponData.imageUrl, imageView: self.couponImageView)
        self.likeButtonView.set(type: .coupon, id: self.couponData.id)
        self.couponTitleLabel.text = self.couponData.title
        self.descriptionLabel.text = self.couponData.body
        self.intervalLabel.text = self.couponData.interval
        self.conditionLabel.text = self.couponData.condition
        
        self.resetLikeCount()
        self.resetReview()
    }
    
    private func resetLikeCount() {
        self.likeLabel.text = "\(LikeRequester.shared.queryLikeCount(type: .coupon, id: self.couponData.id)) likes"
    }
    
    private func resetReview() {
        let score = ReviewRequester.shared.queryTotalScore(type: .coupon, id: self.couponData.id)
        self.scoreLabel.text = ReviewRequester.scoreToString(score)
        self.reviewLabel.text = "\(ReviewRequester.shared.queryReviewCount(type: .coupon, id: self.couponData.id)) reviews"
    }
    
    @IBAction func onTapReview(_ sender: Any) {
        
        let reviewViewController = self.viewController(identifier: "ReviewViewController") as! ReviewViewController
        reviewViewController.set(type: .coupon, id: self.couponData.id)
        self.parent?.stack(viewController: reviewViewController, animationType: .none)
    }
    
    @IBAction func onTapFacebook(_ sender: Any) {
        self.post(to: .facebook)
    }
    
    @IBAction func onTapTwitter(_ sender: Any) {
        self.post(to: .twitter)
    }
    
    @IBAction func onTapBack(_ sender: Any) {
        self.pop(animationType: .horizontal)
    }
    
    private func post(to: SocialType) {
        
        let couponName = self.couponData.title
        let image = ImageStorage.shared.query(url: self.couponData.imageUrl)
        SocialManager.post(to: .facebook, from: self, initialText: couponName, image: image)
    }
}
