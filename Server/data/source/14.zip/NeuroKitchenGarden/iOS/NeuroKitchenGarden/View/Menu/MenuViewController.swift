import UIKit

class MenuViewController: UIViewController {
    
    @IBOutlet private weak var scrollSegmentedControlContainer: UIView!
    @IBOutlet fileprivate weak var scrollView: UIScrollView!
    
    fileprivate var scrollSegmentedControl: ScrollSegmentedControl!
    fileprivate var selectedCategoryIndex = Int(0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let scrollSegmentedControl = UINib(nibName: "ScrollSegmentedControl", bundle: nil).instantiate(withOwner: self, options: nil).first as! ScrollSegmentedControl
        self.scrollSegmentedControlContainer.addSubview(scrollSegmentedControl)
        scrollSegmentedControl.translatesAutoresizingMaskIntoConstraints = false
        scrollSegmentedControl.topAnchor.constraint(equalTo: scrollSegmentedControlContainer.topAnchor).isActive = true
        scrollSegmentedControl.leadingAnchor.constraint(equalTo: scrollSegmentedControlContainer.leadingAnchor).isActive = true
        scrollSegmentedControl.trailingAnchor.constraint(equalTo: scrollSegmentedControlContainer.trailingAnchor).isActive = true
        scrollSegmentedControl.bottomAnchor.constraint(equalTo: scrollSegmentedControlContainer.bottomAnchor).isActive = true
        self.scrollSegmentedControl = scrollSegmentedControl
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if (self.scrollView.subviews.flatMap{ $0 as? MenuView }).isEmpty {
            self.resetData()
        }
    }
    
    private func resetData() {
        
        self.initMenuDatas()
        
        if MenuRequester.shared.dataList.count <= self.selectedCategoryIndex {
            self.selectedCategoryIndex = 0
            self.scrollSegmentedControl.didSelect(at: self.selectedCategoryIndex)
        }
    }
    
    private func initMenuDatas() {
        
        self.scrollSegmentedControl.set(titles: MenuRequester.shared.dataList.map { $0.name }) { index in
            self.scrollView.setContentOffset(CGPoint(x: CGFloat(index) * self.scrollView.frame.size.width, y: 0), animated: true)
        }
        
        self.scrollView.subviews.forEach {
            $0.removeFromSuperview()
        }
        
        for i in 0..<MenuRequester.shared.dataList.count {
            let frame = CGRect(origin: CGPoint(x: CGFloat(i) * self.scrollView.frame.size.width, y: 10),
                               size: self.scrollView.frame.size)
            let collectionView = UINib(nibName: "MenuView", bundle: nil).instantiate(withOwner: self, options: nil).first as! MenuView
            collectionView.frame = frame
            collectionView.setMenuCategory(index: i, callback: { menuData in
                let menuDetailViewController = self.viewController(identifier: "MenuDetailViewController") as! MenuDetailViewController
                menuDetailViewController.set(menuData: menuData)
                self.parent?.stack(viewController: menuDetailViewController, animationType: .horizontal)
            })
            self.scrollView.addSubview(collectionView)
        }
        
        self.scrollView.contentSize = CGSize(width: CGFloat(MenuRequester.shared.dataList.count) * self.scrollView.frame.size.width,
                                             height: self.scrollView.frame.size.height)
    }
}

extension MenuViewController: UIScrollViewDelegate {
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        self.scrollSegmentedControl.didSelect(at: page)
    }
}
