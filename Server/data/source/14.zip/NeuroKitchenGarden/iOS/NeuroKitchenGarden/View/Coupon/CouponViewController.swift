import UIKit

class CouponViewController: UIViewController {
    
    @IBOutlet private weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 100
    }
}

extension CouponViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CouponRequester.shared.dataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CouponTableViewCell", for: indexPath) as! CouponTableViewCell
        cell.configure(data: CouponRequester.shared.dataList[indexPath.row])
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let couponDetailViewController = self.viewController(identifier: "CouponDetailViewController") as! CouponDetailViewController
        couponDetailViewController.set(couponData: CouponRequester.shared.dataList[indexPath.row])
        self.parent?.stack(viewController: couponDetailViewController, animationType: .horizontal)
    }
}
