import UIKit

class NewsTableViewCell: UITableViewCell {
    
    @IBOutlet private weak var newsImageView: UIImageView!
    @IBOutlet private weak var newsTitleLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    
    func configure(newsData: NewsData) {
        
        ImageStorage.shared.fetch(url: newsData.imageUrl, imageView: self.newsImageView)
        self.newsTitleLabel.text = newsData.title
        self.dateLabel.text = newsData.date
    }
}
