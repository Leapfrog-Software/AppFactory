import UIKit

enum ScoreStarType {
    case big
    case small
}

class ScoreContainerView: UIView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        guard let scoreView = UINib(nibName: "ScoreView", bundle: nil).instantiate(withOwner: self, options: nil).first as? ScoreView else {
            return
        }
        self.addSubview(scoreView)
        scoreView.translatesAutoresizingMaskIntoConstraints = false
        scoreView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        scoreView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        scoreView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        scoreView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
    }
    
    func set(type: ScoreStarType) {
        if let scoreView = (self.subviews.flatMap{ $0 as? ScoreView }).first {
            scoreView.set(type: type)
        }
    }
    
    func set(score: Int) {
        
        if let scoreView = (self.subviews.flatMap{ $0 as? ScoreView }).first {
            scoreView.set(score: score)
        }
    }
}

class ScoreView: UIView {
    
    @IBOutlet private weak var starImageView1: UIImageView!
    @IBOutlet private weak var starImageView2: UIImageView!
    @IBOutlet private weak var starImageView3: UIImageView!
    @IBOutlet private weak var starImageView4: UIImageView!
    @IBOutlet private weak var starImageView5: UIImageView!
    
    var scoreStarType: ScoreStarType = .big
    
    func set(type: ScoreStarType) {
        self.scoreStarType = type
    }
    
    func set(score: Int) {
        
        [self.starImageView1, self.starImageView2, self.starImageView3, self.starImageView4, self.starImageView5].enumerated().forEach { i, imageView in
            if score <= i * 2 {
                imageView?.image = UIImage(named: (self.scoreStarType == .big) ? "starEmpty" : "starEmpty_12")
            } else if score == i * 2 + 1 {
                imageView?.image = UIImage(named: (self.scoreStarType == .big) ? "starHalf" : "starHalf_12")
            } else {
                imageView?.image = UIImage(named: (self.scoreStarType == .big) ? "starFull" : "starFull_12")
            }
        }
    }
}
