import UIKit
import MapKit

class HomeViewController: UIViewController {
    
    @IBOutlet private weak var topImageView: UIImageView!
    @IBOutlet private weak var storeNameLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: SpacingLabel!
    @IBOutlet private weak var scoreLabel: UILabel!
    @IBOutlet private weak var reviewLabel: UILabel!
    @IBOutlet private weak var likeButtonView: LikeButtonView!
    @IBOutlet private weak var likeLabel: UILabel!
    @IBOutlet private weak var mapView: MKMapView!
    @IBOutlet private weak var addressLabel: UILabel!
    @IBOutlet private weak var phoneLabel: UILabel!
    @IBOutlet private weak var openCloseTimeLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.resetInformation()
        self.resetReview()
        self.resetLike()
        
        self.likeButtonView.set(type: .home)
    }
    
    private func resetInformation() {
        
        guard let informationData = InformationRequester.shared.informationData else {
            return
        }
        ImageStorage.shared.fetch(url: informationData.imageUrl, imageView: self.topImageView)
        self.storeNameLabel.text = informationData.storeName
        self.descriptionLabel.text = informationData.description
        
        let camera = MKMapCamera()
        if let latitude = CLLocationDegrees(informationData.latitude), let longitude = CLLocationDegrees(informationData.longitude) {
            camera.centerCoordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            camera.altitude = 500
            self.mapView.setCamera(camera, animated: false)
        }
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = camera.centerCoordinate
        annotation.title = ""
        annotation.subtitle = ""
        self.mapView.addAnnotation(annotation)
        
        self.mapView.delegate = self
        
        self.addressLabel.text = informationData.address
        self.phoneLabel.text = informationData.phone
        
        if informationData.openTime.characters.count > 0 && informationData.closeTime.characters.count > 0 {
            self.openCloseTimeLabel.text = informationData.openTime + " - " + informationData.closeTime
        } else {
            self.openCloseTimeLabel.text = informationData.openTime + informationData.closeTime
        }
    }
    
    private func resetReview() {
        let score = ReviewRequester.shared.queryTotalScore(type: .home)
        self.scoreLabel.text = ReviewRequester.scoreToString(score)
        self.reviewLabel.text = "\(ReviewRequester.shared.queryReviewCount(type: .home)) reviews"
    }
    
    private func resetLike() {
        self.likeLabel.text = "\(LikeRequester.shared.queryLikeCount(type: .home)) likes"
    }
    
    @IBAction func onTapReview(_ sender: Any) {
        let reviewViewController = self.viewController(identifier: "ReviewViewController") as! ReviewViewController
        reviewViewController.set(type: .home)
        self.parent?.stack(viewController: reviewViewController, animationType: .none)
    }
    
    @IBAction func onTapFacebook(_ sender: Any) {
        self.post(to: .facebook)
    }
    
    @IBAction func onTapTwitter(_ sender: Any) {
        self.post(to: .twitter)
    }
    
    private func post(to: SocialType) {
        
        guard let informationData = InformationRequester.shared.informationData else {
            return
        }
        let storeName = informationData.storeName
        let storeImage = ImageStorage.shared.query(url: informationData.imageUrl)
        SocialManager.post(to: to, from: self, initialText: storeName, image: storeImage)
    }
}

extension HomeViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let identifier = "annotation"
        
        if let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) {
            return annotationView
        }
        
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
        annotationView.frame = CGRect(x: 0, y: 0, width: 40, height: 80)
        annotationView.backgroundColor = .clear
        
        let imageView = UIImageView(image: UIImage(named: "mapPin"))
        annotationView.addSubview(imageView)
        imageView.frame = CGRect(origin: .zero, size: annotationView.frame.size)
        
        return annotationView
    }
}
