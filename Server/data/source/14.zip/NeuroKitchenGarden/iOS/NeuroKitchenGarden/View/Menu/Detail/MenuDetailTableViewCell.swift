import UIKit

class MenuDetailTableViewCell: UITableViewCell {
    
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    @IBOutlet private weak var scoreContainerView: ScoreContainerView!
    @IBOutlet private weak var messageLabel: UILabel!
    
    func configure(reviewData: ReviewData) {
        
        self.nameLabel.text = reviewData.name
        self.dateLabel.text = DateFormatter(format: "yyyy.MM.dd").string(from: reviewData.date)
        self.messageLabel.text = reviewData.message
        
        self.scoreContainerView.set(type: .small)
        self.scoreContainerView.set(score: reviewData.score)
    }
}
