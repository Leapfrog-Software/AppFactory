import UIKit

class NewsDetailViewController: UIViewController {
    
    @IBOutlet private weak var newsTitleLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    @IBOutlet private weak var newsImageView: UIImageView!
    @IBOutlet private weak var bodyLabel: UILabel!
    
    private var newsData: NewsData!
    
    func set(newsData: NewsData) {
        self.newsData = newsData
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.newsTitleLabel.text = self.newsData.title
        self.dateLabel.text = self.newsData.date
        ImageStorage.shared.fetch(url: self.newsData.imageUrl, imageView: self.newsImageView)
        self.bodyLabel.text = self.newsData.body
    }
    
    @IBAction func onTapBack(_ sender: Any) {
        self.pop(animationType: .horizontal)
    }
}
