import UIKit

class LikeButtonView: UIView {

    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.backgroundColor = .clear
        
        let likeButton = UINib(nibName: "LikeButton", bundle: nil).instantiate(withOwner: self, options: nil).first as! LikeButton
        self.addSubview(likeButton)
        likeButton.translatesAutoresizingMaskIntoConstraints = false
        likeButton.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        likeButton.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        likeButton.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        likeButton.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
    }
    
    func set(type: LikeType, id: String? = nil) {
        if let likeButton = (self.subviews.flatMap{ $0 as? LikeButton }).first {
            likeButton.set(type: type, id: id)
        }
    }
}

class LikeButton: UIView {
    
    @IBOutlet private weak var likeButton: UIButton!
    @IBOutlet private weak var didLikeImageView: UIImageView!
    
    private var likeType: LikeType?
    private var targetId: String?
    
    func set(type: LikeType, id: String? = nil) {
        self.likeType = type
        self.targetId = id
        
        let didSave = !(SaveData.shared.likes.filter { $0.compare(type: type, targetId: id) }).isEmpty
        self.likeButton.isHidden = didSave
        self.didLikeImageView.isHidden = !didSave
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = self.frame.size.width / 2
        self.clipsToBounds = true
    }
    
    @IBAction func onTapLike(_ sender: Any) {
        
        guard let likeType = self.likeType else {
            return
        }
        
        self.isUserInteractionEnabled = false
        
        let postData = LikePostData(type: likeType, target: self.targetId, userId: SaveData.shared.userId)
        LikeRequester.post(data: postData) { [weak self] result in
            if !result {
                self?.isUserInteractionEnabled = true
                return
            }            
            let saveData = SaveData.shared
            let likeSaveData = LikeSaveData(type: likeType, id: self?.targetId)
            saveData.append(likeSaveData: likeSaveData)
            saveData.save()
            
            self?.likeButton.isHidden = true
            self?.didLikeImageView.isHidden = false
            
            LikeRequester.shared.fetch() { _ in }
        }
    }
}

