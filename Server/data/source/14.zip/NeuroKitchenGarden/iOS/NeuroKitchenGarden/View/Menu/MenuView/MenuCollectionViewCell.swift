import UIKit

class MenuCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet private weak var menuImageView: UIImageView!
    @IBOutlet private weak var menuTitleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var priceLabel: UILabel!
    @IBOutlet private weak var scoreContainerView: ScoreContainerView!
    
    func configure(menuData: MenuData) {
        
        ImageStorage.shared.fetch(url: menuData.imageUrl, imageView: self.menuImageView)
        self.menuTitleLabel.text = menuData.name
        self.descriptionLabel.text = menuData.description
        self.priceLabel.text = menuData.price
        
        self.scoreContainerView.set(type: .small)
        let score = Int(ReviewRequester.shared.queryTotalScore(type: .menu, id: menuData.id))
        self.scoreContainerView.set(score: score)
    }
}
