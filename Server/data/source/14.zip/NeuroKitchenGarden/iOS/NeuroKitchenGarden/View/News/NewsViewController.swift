import UIKit

class NewsViewController: UIViewController {
    
    @IBOutlet private weak var tableView: UITableView!
}

extension NewsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return NewsRequester.shared.dataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell", for: indexPath) as! NewsTableViewCell
        cell.configure(newsData: NewsRequester.shared.dataList[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let newsData = NewsRequester.shared.dataList[indexPath.row]
        let newsDetailViewController = self.viewController(identifier: "NewsDetailViewController") as! NewsDetailViewController
        newsDetailViewController.set(newsData: newsData)
        self.parent?.stack(viewController: newsDetailViewController, animationType: .horizontal)
    }
}
