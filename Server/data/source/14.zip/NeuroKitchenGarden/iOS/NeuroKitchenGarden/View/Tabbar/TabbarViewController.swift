import UIKit

class TabbarViewController: UIViewController {

    @IBOutlet private weak var container: UIView!
    @IBOutlet private weak var tab1ImageView: UIImageView!
    @IBOutlet private weak var tab2ImageView: UIImageView!
    @IBOutlet private weak var tab3ImageView: UIImageView!
    @IBOutlet private weak var tab4ImageView: UIImageView!
    
    private var homeViewController: HomeViewController!
    private var couponViewController: CouponViewController!
    private var menuViewController: MenuViewController!
    private var newsViewController: NewsViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initContents()
    }
    
    private func initContents() {
        
        self.homeViewController = self.viewController(identifier: "HomeViewController") as! HomeViewController
        self.addChild(viewController: self.homeViewController)
        self.couponViewController = self.viewController(identifier: "CouponViewController") as! CouponViewController
        self.addChild(viewController: self.couponViewController)
        self.menuViewController = self.viewController(identifier: "MenuViewController") as! MenuViewController
        self.addChild(viewController: self.menuViewController)
        self.newsViewController = self.viewController(identifier: "NewsViewController") as! NewsViewController
        self.addChild(viewController: self.newsViewController)
        
        self.changeTab(index: 0)
    }
    
    private func addChild(viewController: UIViewController) {
        
        self.addChildViewController(viewController)
        self.container.addSubview(viewController.view)
        viewController.didMove(toParentViewController: self)
        
        viewController.view.translatesAutoresizingMaskIntoConstraints = false
        viewController.view.topAnchor.constraint(equalTo: self.container.topAnchor).isActive = true
        viewController.view.leadingAnchor.constraint(equalTo: self.container.leadingAnchor).isActive = true
        viewController.view.trailingAnchor.constraint(equalTo: self.container.trailingAnchor).isActive = true
        viewController.view.bottomAnchor.constraint(equalTo: self.container.bottomAnchor).isActive = true
    }
    
    private func changeTab(index: Int) {
        
        self.homeViewController.view.isHidden = (index != 0)
        self.couponViewController.view.isHidden = (index != 1)
        self.menuViewController.view.isHidden = (index != 2)
        self.newsViewController.view.isHidden = (index != 3)
        
        self.tab1ImageView.image = (index != 0) ? UIImage(named: "tab1") : UIImage(named: "tab1Selected")
        self.tab2ImageView.image = (index != 1) ? UIImage(named: "tab2") : UIImage(named: "tab2Selected")
        self.tab3ImageView.image = (index != 2) ? UIImage(named: "tab3") : UIImage(named: "tab3Selected")
        self.tab4ImageView.image = (index != 3) ? UIImage(named: "tab4") : UIImage(named: "tab4Selected")
    }
    
    @IBAction func onTapTab1(_ sender: Any) {
        self.changeTab(index: 0)
    }
    
    @IBAction func onTapTab2(_ sender: Any) {
        self.changeTab(index: 1)
    }
    
    @IBAction func onTapTab3(_ sender: Any) {
        self.changeTab(index: 2)
    }
    
    @IBAction func onTapTab4(_ sender: Any) {
        self.changeTab(index: 3)
    }
}
