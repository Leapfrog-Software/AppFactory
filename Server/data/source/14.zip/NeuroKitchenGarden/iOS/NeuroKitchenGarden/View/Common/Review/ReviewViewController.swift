import UIKit

class ReviewViewController: UIViewController {
    
    @IBOutlet private weak var scoreContainerView: ScoreContainerView!
    @IBOutlet fileprivate weak var nameTextField: UITextField!
    @IBOutlet fileprivate weak var nameErrorLabel: UILabel!
    @IBOutlet private weak var messageTextView: UITextView!
    @IBOutlet fileprivate weak var messageSuggestLabel: UILabel!
    @IBOutlet private weak var sendButton: UIButton!
    @IBOutlet private weak var loadingImageView: UIImageView!
    @IBOutlet private weak var bottomLayoutConstraint: NSLayoutConstraint!
    
    private var score = Int(6)
    private var touchEnabled = false
    private var reviewType: ReviewType!
    private var targetId: String?
    
    func set(type: ReviewType, id: String? = nil) {
        self.reviewType = type
        self.targetId = id
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.scoreContainerView.set(score: self.score)
        self.changeSendButton(loading: false)
        
        self.setSavedData()
        
        self.nameErrorLabel.isHidden = true
        self.nameTextField.delegate = self
        self.messageTextView.delegate = self
        
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        notificationCenter.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        let notificationCenter = NotificationCenter.default
        notificationCenter.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        notificationCenter.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    private func setSavedData() {
        
        self.nameTextField.text = SaveData.shared.userName
        
        guard let reviewSaveData = (SaveData.shared.reviews.filter { $0.compare(type: self.reviewType, targetId: self.targetId) }).first else {
            return
        }
        self.score = reviewSaveData.score
        self.scoreContainerView.set(score: self.score)
        self.messageTextView.text = reviewSaveData.message ?? ""
        self.messageSuggestLabel.isHidden = self.messageTextView.text.characters.count > 0
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
        
        guard let location = touches.first?.location(in: self.scoreContainerView) else {
            return
        }
        if location.y >= 0 && location.y <= self.scoreContainerView.frame.size.height {
            self.touchEnabled = true
            self.score = self.score(from: location)
            self.scoreContainerView.set(score: self.score)
        } else {
            self.touchEnabled = false
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let location = touches.first?.location(in: self.scoreContainerView) else {
            return
        }
        if self.touchEnabled {
            self.score = self.score(from: location)
            self.scoreContainerView.set(score: self.score)
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.touchEnabled = false
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.touchEnabled = false
    }
    
    private func score(from location: CGPoint) -> Int {
        
        if location.x < 0 {
            return 0
        }
        if location.x >= self.scoreContainerView.frame.size.width {
            return 10
        }
        let starInterval = self.scoreContainerView.frame.size.width / 10
        
        return Int((location.x - starInterval / 2) / starInterval) + 1
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        
        let userInfo = notification.userInfo!
        let keyboardRect = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        self.bottomLayoutConstraint.constant = keyboardRect.size.height
        UIView.animate(withDuration: 0.2) { [weak self] in
            self?.view.layoutIfNeeded()
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        self.bottomLayoutConstraint.constant = 0
        UIView.animate(withDuration: 0.2) { [weak self] in
            self?.view.layoutIfNeeded()
        }
    }
    
    private func changeSendButton(loading: Bool) {
        
        let sendButtonTitle = loading ? "" : "送信"
        self.sendButton.setTitle(sendButtonTitle, for: .normal)
        
        let animationKey = "rotate"
        
        if loading {
            let animation = CABasicAnimation(keyPath: animationKey)
            animation.toValue = NSNumber(value: Double.pi)
            animation.duration = 1.0
            animation.repeatCount = .infinity
            self.loadingImageView.layer.add(animation, forKey: animationKey)
            self.loadingImageView.isHidden = false
        } else {
            self.loadingImageView.layer.removeAnimation(forKey: animationKey)
            self.loadingImageView.isHidden = true
        }
    }
    
    private func save(postData: ReviewPostData) {
        
        let saveData = SaveData.shared
        let reviewSaveData = ReviewSaveData(type: postData.type, id: postData.target, score: postData.score, message: postData.message)
        saveData.append(reviewSaveData: reviewSaveData)
        saveData.userName = postData.name
        saveData.save()
    }
    
    @IBAction func onTapCancel(_ sender: Any) {
        self.pop(animationType: .none)
    }
    
    @IBAction func onTapSend(_ sender: Any) {
        
        self.view.endEditing(true)
        
        guard let name = self.nameTextField.text else {
            return
        }
        if name.characters.count == 0 {
            self.nameErrorLabel.isHidden = false
            self.nameTextField.placeholder = ""
            return
        }
        
        self.changeSendButton(loading: true)
        
        UIApplication.shared.keyWindow?.isUserInteractionEnabled = false
        
        let reviewPostData = ReviewPostData(type: self.reviewType,
                                                            target: self.targetId ?? "",
                                                            userId: SaveData.shared.userId,
                                                            name: name,
                                                            score: self.score,
                                                            message: self.messageTextView.text)
        ReviewRequester.post(data: reviewPostData) { [weak self] result in
            
            UIApplication.shared.keyWindow?.isUserInteractionEnabled = true
            self?.changeSendButton(loading: false)

            if result {
                self?.save(postData: reviewPostData)
                
                self?.sendButton.setTitle("OK", for: .normal)
                self?.sendButton.setTitleColor(.white, for: .normal)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                    self?.pop(animationType: .none)
                }
                
                ReviewRequester.shared.fetch() { _ in }
                
            } else {
                self?.sendButton.setTitle("error", for: .normal)
                self?.sendButton.setTitleColor(.errorText, for: .normal)
            }
        }
    }
}

extension ReviewViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if string.characters.count > 0 {
            self.nameErrorLabel.isHidden = true
            self.nameTextField.placeholder = "お名前を入力してください"
        }
        return true
    }
}

extension ReviewViewController: UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        self.messageSuggestLabel.isHidden = !(range.location == 0 && text == "")
        return true
    }
}
