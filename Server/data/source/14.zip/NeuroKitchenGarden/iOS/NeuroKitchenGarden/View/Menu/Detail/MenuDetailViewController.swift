import UIKit

class MenuDetailViewController: UIViewController {
    
    @IBOutlet private weak var menuImageView: UIImageView!
    @IBOutlet private weak var menuTitleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var priceLabel: UILabel!
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var totalReviewLabel: UILabel!
    @IBOutlet private weak var scoreContainerView: ScoreContainerView!
    
    fileprivate var menuData: MenuData!
    
    func set(menuData: MenuData) {
        self.menuData = menuData
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ImageStorage.shared.fetch(url: self.menuData.imageUrl, imageView: self.menuImageView)
        self.menuTitleLabel.text = self.menuData.name
        self.descriptionLabel.text = self.menuData.description
        self.priceLabel.text = self.menuData.price
        
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 80
        
        self.resetReview()
    }
    
    private func resetReview() {
        
        let reviewCount = ReviewRequester.shared.queryReviewCount(type: .menu, id: self.menuData.id)
        self.totalReviewLabel.text = "Reviews (\(reviewCount))"
        
        let score = ReviewRequester.shared.queryTotalScore(type: .menu, id: self.menuData.id)
        self.scoreContainerView.set(score: Int(score))
        
        self.tableView.reloadData()
    }
    
    @IBAction func onTapReview(_ sender: Any) {
        
        let reviewViewController = self.viewController(identifier: "ReviewViewController") as! ReviewViewController
        reviewViewController.set(type: .menu, id: self.menuData.id)
        self.parent?.stack(viewController: reviewViewController, animationType: .none)
    }
    
    @IBAction func onTapBack(_ sender: Any) {
        self.pop(animationType: .horizontal)
    }
}

extension MenuDetailViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ReviewRequester.shared.queryReviewCount(type: .menu, id: self.menuData.id)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuDetailTableViewCell", for: indexPath) as! MenuDetailTableViewCell
        let reviewData = ReviewRequester.shared.query(type: .menu, id: self.menuData.id)[indexPath.row]
        cell.configure(reviewData: reviewData)
        return cell
    }
}

