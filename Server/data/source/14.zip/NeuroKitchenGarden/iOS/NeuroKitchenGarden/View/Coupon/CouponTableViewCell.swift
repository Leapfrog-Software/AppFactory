import UIKit

class CouponTableViewCell: UITableViewCell {
    
    @IBOutlet private weak var couponImageView: UIImageView!
    @IBOutlet private weak var couponTitleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var scoreLabel: UILabel!
    @IBOutlet private weak var reviewLabel: UILabel!
    @IBOutlet private weak var likeLabel: UILabel!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        ImageStorage.shared.cancelRequest(imageView: self.couponImageView)
        self.couponImageView.image = nil
    }
    
    func configure(data: CouponData) {
        
        ImageStorage.shared.fetch(url: data.imageUrl, imageView: self.couponImageView)
        self.couponTitleLabel.text = data.title
        self.descriptionLabel.text = data.body
        let score = ReviewRequester.shared.queryTotalScore(type: .coupon, id: data.id)
        self.scoreLabel.text = ReviewRequester.scoreToString(score)
        self.reviewLabel.text = "\(ReviewRequester.shared.queryReviewCount(type: .coupon, id: data.id)) reviews"
        self.likeLabel.text = "\(LikeRequester.shared.queryLikeCount(type: .coupon, id: data.id)) likes"
    }
}
