import UIKit

class SplashViewController: UIViewController {

    enum ResultKey: String {
        case information = "Information"
        case coupon = "Coupon"
        case menu = "Menu"
        case news = "News"
        case review = "Review"
        case like = "Like"
    }
    
    private var results = Dictionary<ResultKey, Bool>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.createUserId()
        self.refresh()
    }
    
    private func createUserId() {
        
        let saveData = SaveData.shared
        if saveData.userId.characters.count == 0 {
            saveData.userId = UIDevice.current.identifierForVendor?.uuidString ?? ""
            saveData.save()
        }
    }

    private func refresh() {
        
        self.results.removeAll()
        
        InformationRequester.shared.fetch(completion: { [weak self] (result) in
            self?.results[.information] = result
            self?.checkResult()
        })
        CouponRequester.shared.fetch(completion: { [weak self] (result) in
            self?.results[.coupon] = result
            self?.checkResult()
        })
        MenuRequester.shared.fetch(completion: { [weak self] (result) in
            self?.results[.menu] = result
            self?.checkResult()
        })
        NewsRequester.shared.fetch(completion: { [weak self] (result) in
            self?.results[.news] = result
            self?.checkResult()
        })
        ReviewRequester.shared.fetch(completion: { [weak self] (result) in
            self?.results[.review] = result
            self?.checkResult()
        })
        LikeRequester.shared.fetch(completion: { [weak self] (result) in
            self?.results[.like] = result
            self?.checkResult()
        })
    }
    
    private func checkResult() {
        
        let keys: [ResultKey] = [.information, .coupon, .menu, .news, .review, .like]
        let results = keys.map { self.results[$0] }
        if results.contains(where: { $0 == nil }) {
            return
        }
        
        if results.contains(where: { $0 == false }) {
            self.showError()
        } else {
            self.stackTabbar()
        }
    }
    
    private func stackTabbar() {
        let tabber = self.viewController(identifier: "TabbarViewController")
        self.stack(viewController: tabber, animationType: .none)
    }
    
    private func showError() {        
        let action = AlertAction(title: "リトライ") { [weak self] in
            self?.refresh()
        }
        self.showAlert(title: "エラー", message: "通信に失敗しました", actions: [action])
    }
}
