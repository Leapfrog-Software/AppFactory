import UIKit

class GradationView: UIView {
    
    @IBInspectable var startColor: UIColor = .black
    @IBInspectable var endColor: UIColor = .white
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.sublayers?.forEach {
            $0.removeFromSuperlayer()
        }
        
        let layer = CAGradientLayer()
        layer.frame = CGRect(origin: .zero, size: self.frame.size)
        layer.colors = [
            self.startColor.cgColor,
            self.endColor.cgColor
        ]
        layer.startPoint = CGPoint(x: 0.5, y: 0)
        layer.endPoint = CGPoint(x: 0.5, y: 1)
        
        self.layer.insertSublayer(layer, at: 0)
    }
}
