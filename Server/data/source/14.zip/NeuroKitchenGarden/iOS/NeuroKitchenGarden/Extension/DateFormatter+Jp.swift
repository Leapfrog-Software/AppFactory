import Foundation

extension DateFormatter {
    
    convenience init(format: String) {
        
        self.init()
        self.dateFormat = format
        self.locale = Locale(identifier: "ja_JP")
        self.calendar = Calendar(identifier: .gregorian)
    }
}
