<?php
    
$command = $_POST["command"];

if(strcmp($command, "getInformation") == 0) {
    getInformation();
} else if(strcmp($command, "getCoupon") == 0) {
    getCoupon();
} else if (strcmp($command, "getMenu") == 0) {
    getMenu();
} else if (strcmp($command, "getNews") == 0) {
    getNews();
} else if (strcmp($command, "getReview") == 0) {
    getReview();
} else if (strcmp($command, "postReview") == 0) {
    postReview();
} else if (strcmp($command, "getLike") == 0) {
    getLike();
} else if (strcmp($command, "postLike") == 0) {
    postLike();
} else {
	echo("");
}

function getInformation() {
    echoFileData("data/information.json", "[]");
}
    
function getCoupon() {
    echoFileData("data/coupon.json", "[]");
}
    
function getMenu() {
    echoFileData("data/menu.json", "[]");
}
    
function getNews() {
    echoFileData("data/news.json", "[]");
}
    
function getReview() {
    echoFileData("data/review.json", "[]");
}
    
function postReview() {

    date_default_timezone_set('Asia/Tokyo');

    $fileName = "data/review.json";
    if (file_exists($fileName) == false) {
        echoResult("1");
        return;
    }
    $fileData = file_get_contents($fileName);
    if ($fileData === false) {
        echoResult("1");
        return;
    }
    $json = json_decode($fileData);
    if ($json === false) {
        echoResult("1");
        return;
    }
    if (!is_array($json)) {
        echoResult("1");
        return;
    }
    
    $type = $_POST["type"];
    $target = $_POST["target"];
    $userId = $_POST["userId"];
    
    $data = array(
            "type" => $type,
            "target" => $target,
            "userId" => $userId,
            "name" => $_POST["name"],
            "score" => $_POST["score"],
            "message" => $_POST["message"],
            "date" => date("YmdHis"));
    $found = false;
    for ($i = 0; $i < count($json); $i++) {        
        if ((strcmp($json[$i]->type, $type) == 0)
            && (strcmp($json[$i]->target, $target) == 0)
            && (strcmp($json[$i]->userId, $userId) == 0)) {
            $json[$i] = $data;
            $found = true;
        }
    }
    if ($found == false) {
        $json[] = $data;
    }
    
    $encoded = json_encode($json);
    if ($encoded === false) {
        echoResult("1");
        return;
    }
    if (file_put_contents($fileName, $encoded)) {
        echoResult("0");
    } else {
        echoResult("1");
    }
}
    
function getLike() {
    echoFileData("data/like.json", "[]");
}
    
function postLike() {
    
    $data = array(
                  "type" => $_POST["type"],
                  "target" => $_POST["target"],
                  "userId" => $_POST["userId"]);
    
    if (saveJson("data/like.json", $data)) {
        echoResult("0");
    } else {
        echoResult("1");
    }
}
    
function echoFileData($fileName, $defaultString) {
        
    if (file_exists($fileName)) {
        $fileData = file_get_contents($fileName);
        if ($fileData != false) {
            echo($fileData);
            return;
        }
    }
    echo($defaultString);
}
    
function saveJson($fileName, $data) {

	if (!file_exists($fileName)) {
		return false;
	}

	$fileData = file_get_contents($fileName);
	if ($fileData === false) {
		return false;
	}
	$json = json_decode($fileData);
	if ($json === false) {
		$json = [];
	}
	if (!is_array($json)) {
		$json = [];
	}
	$json[] = $data;

	$encoded = json_encode($json);
	if ($encoded === false) {
		return false;
	}

	return file_put_contents($fileName, $encoded);
}

function echoResult($result) {

    $ret = Array("result" => $result);
    $json = json_encode($ret);
    echo($json);
}

?>
