
import UIKit

extension UIColor {
    
    class var categoryOdd: UIColor {
        return UIColor(red: 25 / 255, green: 34 / 255, blue: 38 / 255, alpha: 1)
    }
    
    class var categoryEven: UIColor {
        return UIColor(red: 49 / 255, green: 62 / 255, blue: 70 / 255, alpha: 1)
    }
    
    class var categoryPointColors: [UIColor] {
        return [
            UIColor(red: 77 / 255, green: 185 / 255, blue: 6 / 255, alpha: 1),
            UIColor(red: 252 / 255, green: 192 / 255, blue: 10 / 255, alpha: 1),
            UIColor(red: 1 / 255, green: 144 / 255, blue: 233 / 255, alpha: 1),
            UIColor(red: 253 / 255, green: 253 / 255, blue: 67 / 255, alpha: 1),
            UIColor(red: 254 / 255, green: 22 / 255, blue: 67 / 255, alpha: 1),
            UIColor(red: 155 / 255, green: 155 / 255, blue: 176 / 255, alpha: 1),
            UIColor(red: 159 / 255, green: 159 / 255, blue: 253 / 255, alpha: 1),
            UIColor(red: 174 / 255, green: 174 / 255, blue: 18 / 255, alpha: 1),
            UIColor(red: 204 / 255, green: 204 / 255, blue: 7 / 255, alpha: 1)
        ]
    }
    
    class var placeholder: UIColor {
        return UIColor(red: 146 / 255, green: 146 / 255, blue: 146 / 255, alpha: 1)
    }
}
