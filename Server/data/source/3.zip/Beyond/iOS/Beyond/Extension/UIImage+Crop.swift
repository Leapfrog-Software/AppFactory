
import UIKit

extension UIImage {
    
    struct Const {
        static let imageSize = CGSize(width: 140, height: 140)
    }
    
    func crop() -> UIImage? {
        
        guard let trimmed = self.trim() else {
            return nil
        }
        return trimmed.resize()
    }
    
    private func trim() -> UIImage? {
        
        var rect = CGRect.zero
        if self.size.width > self.size.height {
            rect = CGRect(x: (self.size.width - self.size.height) / 2,
                          y: 0,
                          width: self.size.height,
                          height: self.size.height)
        } else {
            rect = CGRect(x: 0,
                          y: (self.size.height - self.size.width) / 2,
                          width: self.size.width,
                          height: self.size.width)
        }
        if let cgImage = self.cgImage?.cropping(to: rect) {
            return UIImage(cgImage: cgImage)
        } else {
            return nil
        }
    }
    
    private func resize() -> UIImage? {
        
        UIGraphicsBeginImageContext(Const.imageSize)
        self.draw(in: CGRect(origin: .zero, size: Const.imageSize))
        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return resizedImage
    }
}
