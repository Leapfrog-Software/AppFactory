
import Foundation

enum Gender: String {
    case unspecified = "0"
    case male = "1"
    case female = "2"
    
    var description: String {
        switch self {
        case .unspecified:
            return "Unspecified"
        case .male:
            return "Male"
        case .female:
            return "Female"
        }
    }
    
    static var allValue: [Gender] {
        return [.unspecified, .male, .female]
    }
}

enum AgeGroup: String {
    case unspecified = "0"
    case under20 = "1"
    case s20 = "2"
    case s30 = "3"
    case s40 = "4"
    case s50 = "5"
    case over60 = "6"
    
    var description: String {
        switch self {
        case .unspecified:
            return "Unspecified"
        case .under20:
            return "Under 20"
        case .s20:
            return "20 - 29"
        case .s30:
            return "30 - 39"
        case .s40:
            return "40 - 49"
        case .s50:
            return "50 - 50"
        case .over60:
            return "Over 60"
        }
    }
    
    static var allValue: [AgeGroup] {
        return [.unspecified, .under20, .s20, .s30, s40, .s50, .over60]
    }
}

struct UserData {
    
    let id: String
    var name: String
    var gender: Gender
    var ageGroup: AgeGroup
    var image: String
    
    init?(data: Dictionary<String, Any>) {
        
        guard let id = data["id"] as? String else {
            return nil
        }
        self.id = id
        
        self.name = (data["name"] as? String)?.base64Decode() ?? ""
        self.gender = Gender(rawValue: data["gender"] as? String ?? "") ?? .unspecified
        self.ageGroup = AgeGroup(rawValue: data["ageGroup"] as? String ?? "") ?? .unspecified
        self.image = data["image"] as? String ?? ""
    }
}

class UserRequester {
    
    static let shared = UserRequester()
    
    var dataList = [UserData]()
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        self.dataList.removeAll()
        
        let params = ["command": "getUser"]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                self.dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { UserData(data: $0) }
                completion(true)
                return
            }
            completion(false)
        }
    }
    
    func replace(userId: String, userData: UserData) {
        
        self.dataList.enumerated().forEach { [weak self] i, data in
            if data.id == userId {
                self?.dataList[i] = userData
            }
        }
    }
    
    class func createUser(userId: String, completion: @escaping ((Bool) -> ())) {
        
        let params = [
            "command": "createUser",
            "id": userId
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? [String: String] {
                if data["result"] == "0" {
                    completion(true)
                    return
                }
            }
            completion(false)
        }
    }
    
    class func updateUser(userData: UserData, completion: @escaping ((Bool) -> ())) {
        
        let params = [
            "command": "updateUser",
            "id": userData.id,
            "name": userData.name.base64Encode() ?? "",
            "gender": userData.gender.rawValue,
            "ageGroup": userData.ageGroup.rawValue,
            "image": userData.image
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? [String: String] {
                if data["result"] == "0" {
                    completion(true)
                    return
                }
            }
            completion(false)
        }
    }
    
    func query(userId: String) -> UserData? {
        return self.dataList.filter { $0.id == userId }.first
    }
}
