
import Foundation

struct ChatData {
    
    let id: String
    let userId: String
    let comment: String
    let date: Date
    
    init?(data: Dictionary<String, Any>) {
        self.id = data["id"] as? String ?? ""
        self.userId = data["userId"] as? String ?? ""
        self.comment = (data["comment"] as? String)?.base64Decode() ?? ""
        
        let dateString = data["date"] as? String ?? ""
        guard let date = DateFormatter(dateFormat: "yyyyMMddHHmmss").date(from: dateString) else {
            return nil
        }
        self.date = date
    }
    
    init(id: String, userId: String, comment: String, date: Date) {
        self.id = id
        self.userId = userId
        self.comment = comment
        self.date = date
    }
}

struct ChatPostData {
    let id: String
    let userId: String
    let roomId: String
    let comment: String
}

class ChatRequester {
    
    class func fetch(roomId: String, completion: @escaping ((Bool, [ChatData]?) -> ())) {
        
        let params = [
            "command": "getChat",
            "roomId": roomId
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                let dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { ChatData(data: $0) }
                completion(true, dataList)
                return
            }
            completion(false, nil)
        }
    }
    
    class func post(data: ChatPostData, completion: @escaping ((Bool) -> ())) {
        
        let params = [
            "command": "writeChat",
            "id": data.id,
            "userId": data.userId,
            "roomId": data.roomId,
            "comment": data.comment.base64Encode() ?? ""
        ]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Dictionary<String, String> {
                if data["result"] == "0" {
                    completion(true)
                    return
                }
            }
            completion(false)
        }
    }
}
