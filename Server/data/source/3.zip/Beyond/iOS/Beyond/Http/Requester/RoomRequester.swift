
import Foundation

struct RoomData {
    
    let id: String
    let title: String
    let image: String
    let users: [String]
    
    init?(data: Dictionary<String, Any>) {
        
        guard let id = data["id"] as? String else {
            return nil
        }
        self.id = id
        
        self.title = data["title"] as? String ?? ""
        self.image = data["image"] as? String ?? ""
        
        guard let users = data["users"] as? String else {
            return nil
        }
        self.users = users.components(separatedBy: ",")
    }
}

struct RoomCategoryData {
    
    let id: String
    let title: String
    let rooms: [RoomData]
    
    init?(data: Dictionary<String, Any>) {
        
        guard let id = data["id"] as? String else {
            return nil
        }
        self.id = id
        
        self.title = data["title"] as? String ?? ""
        
        if let roomDatas = data["rooms"] as? [Dictionary<String, Any>] {
            self.rooms = roomDatas.flatMap { RoomData(data: $0) }
        } else {
            self.rooms = [RoomData]()
        }
    }
}

class RoomRequester {
    
    static let shared = RoomRequester()
    
    var dataList = [RoomCategoryData]()
    
    func fetch(completion: @escaping ((Bool) -> ())) {
        
        let params = ["command": "getRoom"]
        ApiManager.post(params: params) { (result, data) in
            if result, let data = data as? Array<Any> {
                self.dataList = data.flatMap { $0 as? Dictionary<String, Any> }.flatMap { RoomCategoryData(data: $0) }
                completion(true)
                return
            }
            completion(false)
        }
    }
}
