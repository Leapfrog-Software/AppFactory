
import UIKit

class ImageUploader {
    
    class func post(image: UIImage, params: [String: String], completion: @escaping ((Bool, String?) -> ())) {
        
        guard let imageData = UIImagePNGRepresentation(image) else {
            completion(false, nil)
            return
        }
        
        var body = Data()
        
        if let data = "--boundary\r\nContent-Disposition: form-data; name=\"command\"\r\n\r\nimageUpload\r\n".data(using: .utf8) {
            body.append(data)
        }
        for (key, value) in params {
            if let data = "--boundary\r\nContent-Disposition: form-data; name=\"\(key)\"\r\n\r\n\(value)\r\n".data(using: .utf8) {
                body.append(data)
            }
        }
        if let data = "--boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"image\"\r\nContent-Type: image/png\r\n\r\n".data(using: .utf8) {
            body.append(data)
        }
        body.append(imageData)
        
        if let data = "\r\n\r\n--boundary--\r\n\r\n".data(using: .utf8) {
            body.append(data)
        }
        
        HttpManager.request(url: Constants.ServerRootUrl + Constants.ServerApplicationName, method: "POST", body: body, additionalHeader: ["Content-Type": "multipart/form-data; boundary=boundary"]) { (result, data) in
            if result, let data = data {
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String: String] {
                        if let result = json["result"], let path = json["path"] {
                            if result == "0" {
                                completion(true, path)
                                return
                            }
                        }
                    }
                } catch {}
            }
            completion(false, nil)
        }
    }
}
