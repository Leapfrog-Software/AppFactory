
import Foundation

struct Constants {
    static let HttpTimeOutInterval = TimeInterval(10)
    static let ServerRootUrl = "https://leapfrog.sakura.ne.jp/samples/beyond/"
    static let ServerApplicationName = "srv.php"
    static let StringEncoding = String.Encoding.utf8
    static let chatRequestTimeInterval = TimeInterval(10)
    
    struct UserDefaultsKey {
        static let UserId = "UserId"
    }
}
