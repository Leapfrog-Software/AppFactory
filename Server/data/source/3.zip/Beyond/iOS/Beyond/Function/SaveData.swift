
import Foundation

class SaveData {
    
    static let shared = SaveData()
    
    var userId = ""
    
    init() {
        let userDefaults = UserDefaults()
        self.userId = userDefaults.string(forKey: Constants.UserDefaultsKey.UserId) ?? ""
    }
    
    func save() {
        
        let userDefaults = UserDefaults()
        userDefaults.set(self.userId, forKey: Constants.UserDefaultsKey.UserId)
        userDefaults.synchronize()
    }
}
