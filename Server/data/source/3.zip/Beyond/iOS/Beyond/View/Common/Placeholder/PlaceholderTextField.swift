
import UIKit

class PlaceholderTextField: UITextField {

    override func awakeFromNib() {
        super.awakeFromNib()
        
        if let placeholder = self.placeholder {
            self.attributedPlaceholder = NSAttributedString(string: placeholder, attributes: [NSAttributedStringKey.foregroundColor: UIColor.placeholder])
            self.placeholder = nil
        }
    }
}
