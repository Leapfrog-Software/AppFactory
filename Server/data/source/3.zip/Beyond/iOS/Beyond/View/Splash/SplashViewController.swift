
import UIKit

class SplashViewController: UIViewController {
    
    enum ResultKey: String {
        case createUser = "CreateUser"
        case user = "User"
        case room = "Room"
    }
    
    private var results = Dictionary<ResultKey, Bool>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.createUser()
    }
    
    private func createUser() {
        
        if SaveData.shared.userId.characters.count > 0 {
            self.results[.createUser] = true
            self.refreshData()
            return
        }
        
        let uuid = (UIDevice.current.identifierForVendor?.uuidString ?? "")
        let currentDate = DateFormatter(dateFormat: "yyyyMMddHHmmss").string(from: Date())
        let userId = uuid + "_" + currentDate
        UserRequester.createUser(userId: userId, completion: { [weak self] result in
            self?.results[.createUser] = result
            if result {
                let saveData = SaveData.shared
                saveData.userId = userId
                saveData.save()
                
                self?.refreshData()
            } else {
                self?.checkResult()
            }
        })
    }
    
    private func refreshData() {
        
        if self.results[.user] != true {
            UserRequester.shared.fetch(completion: { [weak self] result in
                self?.results[.user] = result
                self?.checkResult()
            })
        }
        if self.results[.room] != true {
            RoomRequester.shared.fetch(completion: { [weak self] result in
                self?.results[.room] = result
                self?.checkResult()
            })
        }
    }
    
    private func checkResult() {
        
        let keys: [ResultKey] = [.user, .room, .createUser]
        let results = keys.map { self.results[$0] }
        if results.contains(where: { $0 == nil }) {
            return
        }
        
        if results.contains(where: { $0 == false }) {
            self.showError()
        } else {
            self.stackTop()
        }
    }
    
    private func stackTop() {
        
        let topViewController = self.viewController(identifier: "TopViewController")
        self.stack(viewController: topViewController, animationType: .none)
    }
    
    private func showError() {
        
        let action = AlertAction(title: "リトライ") { [weak self] in
            self?.createUser()
        }
        self.showAlert(title: "エラー", message: "通信に失敗しました", actions: [action])
    }
}
