
import UIKit

class CategoryTableViewCell: UITableViewCell {
    
    @IBOutlet private weak var bgView: UIView!
    @IBOutlet private weak var pointView: UIView!
    @IBOutlet private weak var categoryNameLabel: UILabel!
    @IBOutlet private weak var roomsLabel: UILabel!
    
    func configure(data: RoomCategoryData, row: Int) {
        
        self.bgView.backgroundColor = (row % 2 == 1) ? .categoryOdd : .categoryEven
        let pointColors = UIColor.categoryPointColors
        self.pointView.backgroundColor = pointColors[row % pointColors.count]
        self.categoryNameLabel.text = data.title
        self.roomsLabel.text = "(\(data.rooms.count))"
    }
}
