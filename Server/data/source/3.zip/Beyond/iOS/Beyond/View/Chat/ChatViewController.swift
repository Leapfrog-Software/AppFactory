
import UIKit

class ChatViewController: KeyboardRespondableViewController {
    
    @IBOutlet private weak var roomLabel: UILabel!
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var commentTextView: UITextView!
    @IBOutlet private weak var errorView: UIView!
    @IBOutlet private weak var errorLabel: UILabel!
    @IBOutlet private weak var inputViewBottomConstraint: NSLayoutConstraint!
    
    private var roomId = ""
    fileprivate var chats = [ChatData]()
    fileprivate var tmpChatIds = [String]()
    fileprivate var dummyReceiveCell: ChatReceiveTableViewCell?
    fileprivate var dummySendCell: ChatSendTableViewCell?
    
    func set(roomId: String) {
        self.roomId = roomId
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.dummySendCell = self.tableView.dequeueReusableCell(withIdentifier: "ChatSendTableViewCell") as? ChatSendTableViewCell
        self.dummyReceiveCell = self.tableView.dequeueReusableCell(withIdentifier: "ChatReceiveTableViewCell") as? ChatReceiveTableViewCell
        
        self.errorView.alpha = 0
        
        let categoryData = RoomRequester.shared.dataList.filter { $0.rooms.contains(where: { $0.id == self.roomId }) }.first
        if let roomData = (categoryData?.rooms.filter { $0.id == self.roomId })?.first {
            self.roomLabel.text = roomData.title
        }
        
        Timer.scheduledTimer(timeInterval: Constants.chatRequestTimeInterval, target: self, selector: #selector(update), userInfo: nil, repeats: true).fire()
        self.fetch()
    }
    
    @objc func update(timer: Timer) {
        self.fetch()
    }
    
    private func fetch() {
        
        ChatRequester.fetch(roomId: self.roomId) { [weak self] result, chats in
            if result, let chats = chats {
                self?.chats = chats
                self?.removeTemporaryIds()
                self?.reloadTable()
            }
        }
    }
    
    private func removeTemporaryIds() {
        
        self.chats.forEach { chat in
            if let index = self.tmpChatIds.index(of: chat.id) {
                self.tmpChatIds.remove(at: index)
            }
        }
    }
    
    private func reloadTable() {
        
        self.tableView.reloadData()
        
        if tableView.contentSize.height > self.tableView.frame.size.height {
            let offset = CGPoint(x: 0, y: self.tableView.contentSize.height - self.tableView.frame.size.height)
            self.tableView.setContentOffset(offset, animated: true)
        }
    }
    
    override func animate(with: KeyboardAnimation) {
        self.inputViewBottomConstraint.constant = with.height
        UIView.animate(withDuration: with.duration, delay: 0, options: with.curve, animations: { [weak self] in
            self?.view.layoutIfNeeded()
        })
    }
    
    private func showError(message: String) {
        
        self.errorLabel.text = message
        
        UIView.animate(withDuration: 0.2, animations: { [weak self] in
            self?.errorView.alpha = 1
        }) { _ in
            UIView.animate(withDuration: 0.2, delay: 2, options: .curveEaseInOut, animations: { [weak self] in
                self?.errorView.alpha = 0
            })
        }
    }
    
    @IBAction func onTapSend(_ sender: Any) {
        
        self.view.endEditing(true)
        
        guard let comment = self.commentTextView.text else {
            return
        }
        if comment.characters.count == 0 {
            return
        }
        
        let currentDate = Date()
        let userId = SaveData.shared.userId
        let chatId = userId + DateFormatter(dateFormat: "yyyyMMddHHmmssSSS").string(from: currentDate)
        let chatData = ChatData(id: chatId, userId: userId, comment: comment, date: currentDate)
        self.chats.append(chatData)
        self.tmpChatIds.append(chatId)
        self.reloadTable()
        
        let chatPostData = ChatPostData(id: chatId, userId: userId, roomId: self.roomId, comment: comment)
        ChatRequester.post(data: chatPostData) { [weak self] result in
            if result {
                self?.fetch()
            } else {
                self?.showError(message: "ネットワーク接続に失敗しました")
            }
        }
        
        self.commentTextView.text = ""
    }
    
    @IBAction func onTapClose(_ sender: Any) {
        self.pop(animationType: .horizontal)
    }
}

extension ChatViewController: UITableViewDataSource, UITableViewDelegate, UIScrollViewDelegate {
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.view.endEditing(true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.chats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let chatData = self.chats[indexPath.row]
        if chatData.userId == SaveData.shared.userId {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChatSendTableViewCell", for: indexPath) as! ChatSendTableViewCell
            let isTemporary = self.tmpChatIds.contains(chatData.id)
            cell.configure(data: chatData, isTemporary: isTemporary)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChatReceiveTableViewCell", for: indexPath) as! ChatReceiveTableViewCell
            cell.configure(data: chatData, didTap: { [weak self] in
                let userInformationViewController = self?.viewController(identifier: "UserInformationViewController") as! UserInformationViewController
                userInformationViewController.set(userId: chatData.userId)
                self?.stack(viewController: userInformationViewController, animationType: .horizontal)
            })
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let chatData = self.chats[indexPath.row]
        if chatData.userId == SaveData.shared.userId {
            return self.dummySendCell?.height(data: chatData) ?? 0
        } else {
            return self.dummyReceiveCell?.height(data: chatData) ?? 0
        }
    }
}
