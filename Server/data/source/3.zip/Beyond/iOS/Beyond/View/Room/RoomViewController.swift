
import UIKit

class RoomViewController: UIViewController {
    
    @IBOutlet private weak var roomLabel: UILabel!
    
    private var roomName = ""
    fileprivate var roomDatas = [RoomData]()
    
    func set(categoryId: String) {
        
        self.roomDatas.removeAll()
        
        if let categoryData = (RoomRequester.shared.dataList.filter { $0.id == categoryId }).first {
            self.roomName = categoryData.title
            self.roomDatas = categoryData.rooms
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.roomLabel.text = self.roomName
    }
    
    @IBAction func onTapBack(_ sender: Any) {
        self.pop(animationType: .horizontal)
    }
}

extension RoomViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.roomDatas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RoomTableViewCell", for: indexPath) as! RoomTableViewCell
        cell.configure(data: self.roomDatas[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let chatViewController = self.viewController(identifier: "ChatViewController") as! ChatViewController
        chatViewController.set(roomId: self.roomDatas[indexPath.row].id)
        self.stack(viewController: chatViewController, animationType: .horizontal)
    }
}
