
import UIKit

class ChatReceiveTableViewCell: UITableViewCell {
    
    struct Const {
        static let bottomMargin = CGFloat(26)
    }
    
    @IBOutlet private weak var faceImageView: UIImageView!
    @IBOutlet private weak var baloonView: UIView!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var commentLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    
    private var didTap: (() -> ())?
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        self.didTap = nil
        
        ImageStorage.shared.cancelRequest(imageView: self.faceImageView)
    }
    
    func configure(data: ChatData, didTap: (() -> ())? = nil) {
        
        let userData = UserRequester.shared.query(userId: data.userId)
        ImageStorage.shared.fetch(url: userData?.image ?? "", imageView: self.faceImageView, defaultImage: UIImage(named: "noUserImage"))
        
        self.nameLabel.text = UserRequester.shared.query(userId: data.userId)?.name ?? "(No Name)"
        self.commentLabel.text = data.comment
        self.dateLabel.text = String(date: data.date)
        self.didTap = didTap
    }
    
    func height(data: ChatData) -> CGFloat {
        
        self.configure(data: data)
        
        self.setNeedsLayout()
        self.layoutIfNeeded()
        
        return self.baloonView.frame.origin.y + self.baloonView.frame.size.height + Const.bottomMargin
    }
    
    @IBAction func onTapFace(_ sender: Any) {
        self.didTap?()
    }
}
