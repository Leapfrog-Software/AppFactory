
import UIKit

class RoomTableViewCell: UITableViewCell {
    
    @IBOutlet private weak var roomImageView: UIImageView!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var userImageView1: UIImageView!
    @IBOutlet private weak var userImageView2: UIImageView!
    @IBOutlet private weak var userImageView3: UIImageView!
    @IBOutlet private weak var userImageView4: UIImageView!
    @IBOutlet private weak var userCountLabel: UILabel!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        ImageStorage.shared.cancelRequest(imageView: self.roomImageView)
        ImageStorage.shared.cancelRequest(imageView: self.userImageView1)
        ImageStorage.shared.cancelRequest(imageView: self.userImageView2)
        ImageStorage.shared.cancelRequest(imageView: self.userImageView3)
        ImageStorage.shared.cancelRequest(imageView: self.userImageView4)
    }
    
    func configure(data: RoomData) {
        
        ImageStorage.shared.fetch(url: data.image, imageView: self.roomImageView)
        self.nameLabel.text = data.title
        
        self.fetchUserImage(userId: (data.users.count >= 1) ? data.users[0] : nil, imageView: self.userImageView1)
        self.fetchUserImage(userId: (data.users.count >= 2) ? data.users[1] : nil, imageView: self.userImageView2)
        self.fetchUserImage(userId: (data.users.count >= 3) ? data.users[2] : nil, imageView: self.userImageView3)
        self.fetchUserImage(userId: (data.users.count >= 4) ? data.users[3] : nil, imageView: self.userImageView4)
        
        self.userCountLabel.text = "\(data.users.count)" + " users"
    }
    
    private func fetchUserImage(userId: String?, imageView: UIImageView) {
        
        if let userId = userId, let userData = UserRequester.shared.query(userId: userId) {
            imageView.isHidden = false
            ImageStorage.shared.fetch(url: userData.image, imageView: imageView, defaultImage: UIImage(named: "noUserImage"))
        } else {
            imageView.isHidden = true
        }
    }
}
