
import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet fileprivate weak var faceImageView: UIImageView!
    @IBOutlet private weak var nameTextField: PlaceholderTextField!
    @IBOutlet private weak var genderLabel: UILabel!
    @IBOutlet private weak var ageGroupLabel: UILabel!
    
    fileprivate var selectedImage: UIImage?
    private var selectedGender = Gender.unspecified
    private var selectedAgeGroup = AgeGroup.unspecified
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let userData = (UserRequester.shared.dataList.filter { $0.id == SaveData.shared.userId }.first) {
            ImageStorage.shared.fetch(url: userData.image, imageView: self.faceImageView, defaultImage: UIImage(named: "noUserImage"))
            self.nameTextField.text = userData.name
            self.genderLabel.text = userData.gender.description
            self.ageGroupLabel.text = userData.ageGroup.description
            self.selectedGender = userData.gender
            self.selectedAgeGroup = userData.ageGroup
        }
    }
    
    @IBAction func onTapFace(_ sender: Any) {
        
        if !UIImagePickerController.isSourceTypeAvailable(.camera) {
            return
        }
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .camera
        self.present(imagePickerController, animated: true)
    }
    
    @IBAction func didEndEditName(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    @IBAction func onTapGender(_ sender: Any) {
        
        self.view.endEditing(true)
        
        let defaultIndex = Gender.allValue.index(of: self.selectedGender) ?? 0
        let pickerViewController = self.viewController(identifier: "PickerViewController") as! PickerViewController
        pickerViewController.set(title: "Gender", dataArray: Gender.allValue.map { $0.description }, defaultIndex: defaultIndex) { [weak self] index in
            self?.selectedGender = Gender.allValue[index]
            self?.genderLabel.text = self?.selectedGender.description
        }
        self.stack(viewController: pickerViewController, animationType: .none)
    }
    
    @IBAction func onTapAgeGroup(_ sender: Any) {
        
        self.view.endEditing(true)
        
        let defaultIndex = AgeGroup.allValue.index(of: self.selectedAgeGroup) ?? 0
        let pickerViewController = self.viewController(identifier: "PickerViewController") as! PickerViewController
        pickerViewController.set(title: "Age group", dataArray: AgeGroup.allValue.map { $0.description }, defaultIndex: defaultIndex) { [weak self] index in
            self?.selectedAgeGroup = AgeGroup.allValue[index]
            self?.ageGroupLabel.text = self?.selectedAgeGroup.description
        }
        self.stack(viewController: pickerViewController, animationType: .none)
    }
    
    @IBAction func onTapUpdate(_ sender: Any) {
        
        self.view.endEditing(true)
        
        Loading.start()
        
        if let selectedImage = self.selectedImage {
            ImageUploader.post(image: selectedImage, params: ["userId": SaveData.shared.userId], completion: { [weak self] result, path in
                if result {
                    self?.updateUserData(userImagePath: path)
                } else {
                    Loading.stop()
                    self?.showError()
                }
            })
        } else {
            self.updateUserData(userImagePath: nil)
        }
    }
    
    private func updateUserData(userImagePath: String?) {
        
        guard var userData = (UserRequester.shared.dataList.filter { $0.id == SaveData.shared.userId }.first),
            let name = self.nameTextField.text else {
                Loading.stop()
                return
        }
        
        userData.name = name
        userData.gender = self.selectedGender
        userData.ageGroup = self.selectedAgeGroup
        
        if let userImagePath = userImagePath {
            userData.image = Constants.ServerRootUrl + userImagePath
        }
        
        UserRequester.updateUser(userData: userData) { [weak self] result in
            Loading.stop()
            if result {
                let action = AlertAction(title: "OK", action: { [weak self] in
                    self?.pop(animationType: .vertical)
                })
                self?.showAlert(title: "プロフィールを更新しました", message: nil, actions: [action])
                UserRequester.shared.replace(userId: SaveData.shared.userId, userData: userData)
            } else {
                self?.showError()
            }
        }
    }
    
    private func showError() {
        let action = AlertAction(title: "OK")
        self.showAlert(title: "エラー", message: "通信に失敗しました", actions: [action])
    }
    
    @IBAction func onTapClose(_ sender: Any) {
        
        self.pop(animationType: .vertical)
    }
}

extension ProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            self.selectedImage = image.crop()
            self.faceImageView.image = self.selectedImage
        }
        picker.dismiss(animated: true)
    }
}
