
import UIKit

import UIKit

class TopViewController: UIViewController {
    
    @IBAction func onTapCategory(_ sender: Any) {
        
        let categoryViewController = self.viewController(identifier: "CategoryViewController") as! CategoryViewController
        self.stack(viewController: categoryViewController, animationType: .vertical)
    }
    
    @IBAction func onTapProfile(_ sender: Any) {
        
        let profileViewController = self.viewController(identifier: "ProfileViewController") as! ProfileViewController
        self.stack(viewController: profileViewController, animationType: .vertical)
    }
}
