
import UIKit

class CategoryViewController: UIViewController {
    
    @IBAction func onTapClose(_ sender: Any) {
        self.pop(animationType: .vertical)
    }
}

extension CategoryViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return RoomRequester.shared.dataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryTableViewCell", for: indexPath) as! CategoryTableViewCell
        cell.configure(data: RoomRequester.shared.dataList[indexPath.row], row: indexPath.row)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let roomViewController = self.viewController(identifier: "RoomViewController") as! RoomViewController
        roomViewController.set(categoryId: RoomRequester.shared.dataList[indexPath.row].id)
        self.stack(viewController: roomViewController, animationType: .horizontal)
    }
}
