
import UIKit

class ChatSendTableViewCell: UITableViewCell {
    
    struct Const {
        static let bottomMargin = CGFloat(26)
    }
    
    @IBOutlet private weak var faceImageView: UIImageView!
    @IBOutlet private weak var baloonView: UIView!
    @IBOutlet private weak var commentLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    @IBOutlet private weak var coverView: UIView!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        self.faceImageView.image = nil
        ImageStorage.shared.cancelRequest(imageView: self.faceImageView)
    }
    
    func configure(data: ChatData, isTemporary: Bool) {
        
        self.faceImageView.image = nil
        if let userData = UserRequester.shared.query(userId: SaveData.shared.userId) {
            ImageStorage.shared.fetch(url: userData.image, imageView: self.faceImageView, defaultImage: UIImage(named: "noUserImage"))
        }
        self.commentLabel.text = data.comment
        self.dateLabel.text = String(date: data.date)
        self.coverView.isHidden = !isTemporary
    }
    
    func height(data: ChatData) -> CGFloat {
        
        self.configure(data: data, isTemporary: false)
        
        self.setNeedsLayout()
        self.layoutIfNeeded()
        
        return self.baloonView.frame.origin.y + self.baloonView.frame.size.height + Const.bottomMargin
    }
}
