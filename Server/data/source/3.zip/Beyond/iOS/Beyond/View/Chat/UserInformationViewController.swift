
import UIKit

class UserInformationViewController: UIViewController {

    @IBOutlet private weak var faceImageView: UIImageView!
    @IBOutlet private weak var userNameLabel: UILabel!
    @IBOutlet private weak var genderLabel: UILabel!
    @IBOutlet private weak var ageGroupLabel: UILabel!

    private var userId = ""
    
    func set(userId: String) {
        self.userId = userId
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let userData = UserRequester.shared.query(userId: self.userId) else {

            self.userNameLabel.text = ""
            self.genderLabel.text = ""
            self.ageGroupLabel.text = ""
            return
        }
        ImageStorage.shared.fetch(url: userData.image, imageView: self.faceImageView, defaultImage: UIImage(named: "noUserImage"))
        self.userNameLabel.text = userData.name.characters.count > 0 ? userData.name : "(No Name)"
        self.genderLabel.text = userData.gender.description
        self.ageGroupLabel.text = userData.ageGroup.description
    }
    
    
    @IBAction func onTapBack(_ sender: Any) {
        self.pop(animationType: .horizontal)
    }
}
