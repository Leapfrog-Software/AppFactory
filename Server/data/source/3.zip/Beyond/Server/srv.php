<?php
    
$command = $_POST["command"];

if(strcmp($command, "getUser") == 0) {
    getUser();
} else if (strcmp($command, "createUser") == 0) {
    createUser();
} else if (strcmp($command, "updateUser") == 0) {
    updateUser();
} else if(strcmp($command, "getRoom") == 0) {
    getRoom();
} else if (strcmp($command, "getChat") == 0) {
    getChat();
} else if (strcmp($command, "writeChat") == 0) {
    writeChat();
} else if (strcmp($command, "imageUpload") == 0) {
    imageUpload();
}
    
function getUser() {
    echoFileData("data/user.json", "[]");
}
    
function createUser() {
    
    date_default_timezone_set('Asia/Tokyo');
    
    $data = array(
        "id" => $_POST["id"],
        "createDate" => date("YmdHis"));
    
    if (saveJson("data/user.json", $data)) {
        echoResult("0");
    } else {
        echoResult("1");
    }
}
    
function updateUser() {
    
    $fileName = "data/user.json";
    if (file_exists($fileName) == false) {
        echoResult("1");
        return;
    }
    $fileData = file_get_contents($fileName);
    if ($fileData === false) {
        echoResult("1");
        return;
    }
    $json = json_decode($fileData);
    if ($json === false) {
        echoResult("1");
        return;
    }
    if (!is_array($json)) {
        echoResult("1");
        return;
    }
    
    $userId = $_POST["id"];

    date_default_timezone_set('Asia/Tokyo');

    $data = array(
		"id" => $userId,
		"name" => $_POST["name"],
        "gender" => $_POST["gender"],
		"ageGroup" => $_POST["ageGroup"],
		"image" => $_POST["image"],
        "createDate" => date("YmdHis"));

    $found = false;
    for ($i = 0; $i < count($json); $i++) {
        
        if (strcmp($json[$i]->id, $userId) == 0) {

            $json[$i] = $data;
            $found = true;
        }
    }
    if ($found == false) {
        $json[] = $data;
    }
    
    $encoded = json_encode($json);
    if ($encoded === false) {
        echoResult("1");
        return;
    }
    if (file_put_contents($fileName, $encoded)) {
        echoResult("0");
    } else {
        echoResult("1");
    }
}

function getRoom() {
    echoFileData("data/room.json", "[]");
}
    
function getChat() {

    $roomId = $_POST["roomId"];
    $fileName = "data/chat/" . $roomId . ".json";
    echoFileData($fileName, "[]");
}

function writeChat() {

    $id = $_POST["id"];
    $roomId = $_POST["roomId"];
    $userId = $_POST["userId"];
    $comment = $_POST["comment"];
    
    if (addChatFile($id, $roomId, $userId, $comment)) {
    	if (updateRoomFile($roomId, $userId)) {
    		echoResult("0");
    		return;
    	}
    }
    echoResult("1");
}

function imageUpload() {

    $fileName = "data/image/user/" . $_POST["userId"] . ".png";
    if (move_uploaded_file($_FILES['image']['tmp_name'], $fileName)) {
        $ret = Array("result" => "0",
                     "path" => $fileName);
        $json = json_encode($ret);
        echo($json);
    } else {
        echoResult("1");
    }
}

function addChatFile($id, $roomId, $userId, $comment) {

	date_default_timezone_set('Asia/Tokyo');

    $data = array(
    			"id" => $id,
                "userId" => $userId,
                "comment" => $comment,
                "date" => date("YmdHis"));

    $fileName = "data/chat/" . $roomId . ".json";
    
    if (saveJson($fileName, $data)) {
    	return true;
    } else {
        return false;
    }
}

function updateRoomFile($roomId, $userId) {

	$fileData = file_get_contents("data/room.json");
	if ($fileData === false) {
		return false;
	}
	$json = json_decode($fileData);
	if ($json === false) {
		return false;
	}
	if (!is_array($json)) {
		return false;
	}
	for ($i = 0; $i < count($json); $i++) {
		$rooms = $json[$i]->rooms;
		if (!is_array($rooms)) {
			continue;
		}
		for ($j = 0; $j < count($rooms); $j++) {
			if (strcmp($rooms[$j]->id, $roomId) == 0) {
				$users = $rooms[$j]->users;
				$exploded = explode(",", $users);
				$filterred = array_filter($exploded);
				$found = false;
				for ($k = 0; $k < count($filterred); $k++) {
					if (strcmp($filterred[$k], $userId) == 0) {
						$found = true;
						break;
					}
				}
				if (!$found) {
					$filterred[] = $userId;
					$users = implode(",", $filterred);
					$json[$i]->rooms[$j]->users = $users;
					$encoded = json_encode($json);
					return file_put_contents("data/room.json", $encoded);
				} else {
					return true;
				}
			}
		}
	}
	return false;
}

function echoFileData($fileName, $defaultString) {
        
    if (file_exists($fileName)) {
        $fileData = file_get_contents($fileName);
        if ($fileData != false) {
            echo($fileData);
            return;
        }
    }
    echo($defaultString);
}

function saveJson($fileName, $data) {

    $fileData = "[]";
    
	if (file_exists($fileName)) {
        $fileData = file_get_contents($fileName);
        if ($fileData === false) {
            return false;
        }
	}

	$json = json_decode($fileData);
	if ($json === false) {
		$json = [];
	}
	if (!is_array($json)) {
		$json = [];
	}
	$json[] = $data;

	$encoded = json_encode($json);
	if ($encoded === false) {
		return false;
	}
	return file_put_contents($fileName, $encoded);
}

function echoResult($result) {

    $ret = Array("result" => $result);
    $json = json_encode($ret);
    echo($json);
}

?>
